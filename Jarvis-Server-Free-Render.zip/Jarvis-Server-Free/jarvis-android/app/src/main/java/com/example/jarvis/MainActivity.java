package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {
    private static final int RECORD_AUDIO_REQUEST = 7;
    private static final String SECURE_PREFS = "jarvis_secure_settings";
    private static final String TOKEN_CIPHERTEXT = "server_token_ciphertext";
    private static final String TOKEN_IV = "server_token_iv";
    private static final String KEY_ALIAS = "jarvis_server_token_key";
    private static final int MAX_RESPONSE_BYTES = 100_000;

    private WebView web;
    private TextToSpeech textToSpeech;
    private SpeechRecognizer speechRecognizer;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidJarvis");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                configureHindiVoice();
            }
        });

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    RECORD_AUDIO_REQUEST
            );
        }
    }

    private void configureHindiVoice() {
        if (textToSpeech == null) {
            return;
        }

        int languageStatus = textToSpeech.setLanguage(new Locale("hi", "IN"));
        if (languageStatus == TextToSpeech.LANG_MISSING_DATA
                || languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
            return;
        }

        Set<Voice> availableVoices = textToSpeech.getVoices();
        Voice hindiMaleVoice = null;
        if (availableVoices != null) {
            for (Voice voice : availableVoices) {
                if (voice == null
                        || voice.getLocale() == null
                        || !"hi".equalsIgnoreCase(voice.getLocale().getLanguage())) {
                    continue;
                }

                String name = voice.getName().toLowerCase(Locale.ROOT);
                if (name.contains("male") && !name.contains("female")
                        && (hindiMaleVoice == null
                        || voice.getQuality() > hindiMaleVoice.getQuality())) {
                    hindiMaleVoice = voice;
                }
            }
        }

        if (hindiMaleVoice != null) {
            textToSpeech.setVoice(hindiMaleVoice);
        }
        textToSpeech.setPitch(0.88f);
        textToSpeech.setSpeechRate(0.95f);
    }

    private SharedPreferences securePreferences() {
        return getSharedPreferences(SECURE_PREFS, MODE_PRIVATE);
    }

    private SecretKey getOrCreateEncryptionKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);

        if (keyStore.containsAlias(KEY_ALIAS)) {
            return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        }

        KeyGenerator keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
        );
        keyGenerator.init(
                new KeyGenParameterSpec.Builder(
                        KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
                )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setRandomizedEncryptionRequired(true)
                        .build()
        );
        return keyGenerator.generateKey();
    }

    private boolean saveEncryptedServerToken(String rawToken) {
        if (rawToken == null) {
            return false;
        }

        String token = rawToken.trim();
        if (token.length() < 24) {
            return false;
        }

        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateEncryptionKey());
            byte[] ciphertext = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));

            return securePreferences()
                    .edit()
                    .putString(
                            TOKEN_CIPHERTEXT,
                            Base64.encodeToString(ciphertext, Base64.NO_WRAP)
                    )
                    .putString(
                            TOKEN_IV,
                            Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP)
                    )
                    .commit();
        } catch (Exception ignored) {
            return false;
        }
    }

    private String readEncryptedServerToken() {
        String ciphertext = securePreferences().getString(TOKEN_CIPHERTEXT, null);
        String initializationVector = securePreferences().getString(TOKEN_IV, null);
        if (ciphertext == null || initializationVector == null) {
            return null;
        }

        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec parameters = new GCMParameterSpec(
                    128,
                    Base64.decode(initializationVector, Base64.NO_WRAP)
            );
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateEncryptionKey(), parameters);
            byte[] plaintext = cipher.doFinal(
                    Base64.decode(ciphertext, Base64.NO_WRAP)
            );
            String token = new String(plaintext, StandardCharsets.UTF_8);
            return token.length() >= 24 ? token : null;
        } catch (Exception ignored) {
            clearEncryptedServerToken();
            return null;
        }
    }

    private boolean clearEncryptedServerToken() {
        try {
            boolean cleared = securePreferences()
                    .edit()
                    .remove(TOKEN_CIPHERTEXT)
                    .remove(TOKEN_IV)
                    .commit();

            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) {
                keyStore.deleteEntry(KEY_ALIAS);
            }
            return cleared;
        } catch (Exception ignored) {
            return false;
        }
    }

    private URL validateChatEndpoint(String endpoint) throws Exception {
        URL url = new URL(endpoint.trim());
        if (!"https".equalsIgnoreCase(url.getProtocol())
                || url.getHost() == null
                || url.getHost().isEmpty()
                || url.getUserInfo() != null
                || !url.getPath().endsWith("/api/chat")) {
            throw new IllegalArgumentException(
                    "HTTPS URL must point to the /api/chat endpoint."
            );
        }
        return url;
    }

    private String readResponse(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }

        try (InputStream input = stream;
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
                if (output.size() > MAX_RESPONSE_BYTES) {
                    throw new IllegalStateException("Response body is too large.");
                }
            }
            return output.toString("UTF-8");
        }
    }

    private String requestOnlineReply(String question, String endpoint) {
        if (question == null || question.trim().isEmpty() || question.length() > 1500) {
            return "सर, संदेश 1 से 1500 अक्षरों के बीच होना चाहिए।";
        }

        String token = readEncryptedServerToken();
        if (token == null) {
            return "सर, Online AI इस्तेमाल करने से पहले सेटिंग्स में server access token सेव करें।";
        }

        HttpsURLConnection connection = null;
        try {
            URL url = validateChatEndpoint(endpoint);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(12_000);
            connection.setReadTimeout(45_000);
            connection.setInstanceFollowRedirects(false);
            connection.setDoOutput(true);
            connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
            );
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + token);

            byte[] body = new JSONObject()
                    .put("message", question.trim())
                    .toString()
                    .getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
            }

            int statusCode = connection.getResponseCode();
            InputStream responseStream = statusCode >= 200 && statusCode < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            String rawResponse = readResponse(responseStream);
            JSONObject response = new JSONObject(rawResponse);

            if (statusCode == HttpsURLConnection.HTTP_UNAUTHORIZED) {
                return "सर, server access token सही नहीं है। सेटिंग्स में token फिर से सेव करें।";
            }
            if (statusCode == 429) {
                return "सर, अभी अनुरोध सीमा पूरी हुई है। थोड़ी देर बाद फिर कोशिश करें।";
            }
            if (statusCode < 200 || statusCode >= 300) {
                return "सर, Online AI सर्वर उपलब्ध नहीं है। URL और सर्वर स्थिति जाँचें।";
            }

            String reply = response.optString("reply", "").trim();
            return reply.isEmpty() ? "माफ़ कीजिए सर, अभी जवाब नहीं मिला।" : reply;
        } catch (SocketTimeoutException ignored) {
            return "सर, Online AI ने समय पर जवाब नहीं दिया। फिर कोशिश करें।";
        } catch (JSONException ignored) {
            return "सर, Online AI सर्वर से सही जवाब नहीं मिला।";
        } catch (Exception ignored) {
            return "सर, Online AI उपलब्ध नहीं है। इंटरनेट और HTTPS server URL जाँचें।";
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public boolean hasServerAccessToken() {
            return securePreferences().contains(TOKEN_CIPHERTEXT)
                    && securePreferences().contains(TOKEN_IV);
        }

        @JavascriptInterface
        public boolean saveServerAccessToken(String token) {
            return saveEncryptedServerToken(token);
        }

        @JavascriptInterface
        public boolean clearServerAccessToken() {
            return clearEncryptedServerToken();
        }

        @JavascriptInterface
        public void askAI(String question, String server) {
            Thread requestThread = new Thread(() -> {
                String reply = requestOnlineReply(question, server);
                runOnUiThread(() -> {
                    if (web != null) {
                        web.evaluateJavascript(
                                "window.jarvisAIResult("
                                        + JSONObject.quote(reply)
                                        + ")",
                                null
                        );
                    }
                });
            }, "jarvis-online-ai");
            requestThread.start();
        }

        @JavascriptInterface
        public void speak(String text) {
            runOnUiThread(() -> {
                if (textToSpeech != null) {
                    textToSpeech.speak(
                            text,
                            TextToSpeech.QUEUE_FLUSH,
                            null,
                            "jarvis"
                    );
                }
            });
        }

        @JavascriptInterface
        public void listen() {
            runOnUiThread(MainActivity.this::startListening);
        }
    }

    private void sendSpeechResult(String speech, String error) {
        String speechJson = JSONObject.quote(speech == null ? "" : speech);
        String errorJson = error == null ? "null" : JSONObject.quote(error);
        web.evaluateJavascript(
                "window.jarvisSpeechResult(" + speechJson + "," + errorJson + ")",
                null
        );
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    RECORD_AUDIO_REQUEST
            );
            sendSpeechResult(null, "माइक्रोफोन अनुमति दें और फिर कोशिश करें।");
            return;
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendSpeechResult(null, "इस फोन पर Speech Recognition सेवा उपलब्ध नहीं है।");
            return;
        }

        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle parameters) {}

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {}

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                sendSpeechResult(
                        null,
                        "आवाज़ पहचान में त्रुटि हुई। फिर कोशिश करें।"
                );
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                sendSpeechResult(
                        matches != null && !matches.isEmpty() ? matches.get(0) : "",
                        null
                );
            }

            @Override
            public void onPartialResults(Bundle partialResults) {}

            @Override
            public void onEvent(int eventType, Bundle parameters) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        );
        speechRecognizer.startListening(intent);
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
