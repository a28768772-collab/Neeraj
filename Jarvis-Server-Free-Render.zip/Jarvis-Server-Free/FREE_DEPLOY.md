# JARVIS Server — Free deployment (Render)

This version removes the Replit-only runtime pieces from the API server. It is designed to run as a Docker web service on Render's Free plan.

## 1. Put the project on GitHub

Create a new GitHub repository and upload this project. Do not upload `.env` files or API keys.

## 2. Create the Render service

In Render:

- New → Web Service
- Connect the GitHub repository
- Runtime: Docker
- Plan: Free
- Health Check Path: `/health`

If Render detects `render.yaml`, the included settings can be used.

## 3. Add secrets

In Render → Environment:

- `OPENAI_API_KEY` = your OpenAI API key
- `JARVIS_ACCESS_TOKEN` = a random secret of at least 24 characters
- `OPENAI_MODEL` = `gpt-4.1-mini` (or another model available to your API account)

Never put these values in GitHub.

## 4. Test

After deployment, open:

`https://YOUR-SERVICE.onrender.com/health`

Expected response:

`{"status":"ok","name":"JARVIS"}`

## 5. Android app

Use your Render URL as the JARVIS server base URL and send the same bearer token in the `Authorization` header.

The chat endpoint is:

`POST https://YOUR-SERVICE.onrender.com/api/chat`

JSON body:

`{"message":"नमस्ते सर"}`

Header:

`Authorization: Bearer YOUR_JARVIS_ACCESS_TOKEN`

## Important

Render's free web service sleeps after 15 minutes without incoming traffic and can take about a minute to wake up. Render's free PostgreSQL database also expires after 30 days, but this API build does not require a database at runtime because the current JARVIS routes do not use the DB package.

OpenAI API usage is separate from hosting and may require OpenAI API billing/credits.
