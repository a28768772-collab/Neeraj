# JARVIS Android client

This Android project uses a local HTML interface inside a Java WebView. The
Android app talks to the Node.js API server already configured for this
workspace:

```text
POST https://<reachable-host>/api/chat
Content-Type: application/json
Authorization: Bearer <JARVIS_ACCESS_TOKEN>

{"message":"नमस्ते Jarvis"}
```

The Android project does not contain an OpenAI API key. OpenAI requests are
made by the server.

## Configure the app

1. Open this project in Android Studio and build/install the app.
2. Create or unlock the local JARVIS PIN.
3. In **Online AI सेटिंग**, the published HTTPS chat endpoint is prefilled:
   `https://jarvis-server--Neeraj2004.replit.app/api/chat`. It can be changed
   later if the server address changes.
4. Enter the same `JARVIS_ACCESS_TOKEN` value configured in the server's Replit
   Secrets, then choose **इस डिवाइस पर सुरक्षित सेव करें**.
5. The app encrypts the access token with Android Keystore. It is not written
   into the source code, HTML, Gradle configuration, or browser local storage.
   Use **Token हटाएँ** to remove it from this device.

This is intended for a personal, trusted device. A shared bearer token may still
be extracted from a rooted or compromised device at runtime; do not distribute
one shared token to untrusted users. Use individual server-side accounts before
sharing the service more broadly.

The Replit server also needs `OPENAI_API_KEY` in Replit Secrets. Never enter
that key in this Android app. Each online message uses the OpenAI account
associated with that server key and may incur provider charges.

## Features retained

- Hindi-first assistant that addresses the user as “Sir”
- Online AI replies through the existing server
- Offline text commands for time, date, calculations, stories, jokes, help,
  greetings, and the phone-unlock explanation
- Hindi speech recognition and Android text-to-speech voice replies
- Neon-blue interface
- Local PIN lock and voice shortcut to the PIN screen

The PIN remains the original local demo lock. It does not replace Android's
system lock or provide production-grade account security. Speech recognition
availability depends on the device's installed Android speech service.

## Server address availability

The published API is public at
`https://jarvis-server--Neeraj2004.replit.app`. Use `/api/chat` for conversation
requests and `/health` for a health check. The bare `/` path is not a webpage
and may return 404; that does not indicate a missing chat endpoint.

On Android, JARVIS prefers a Hindi voice explicitly named as male by the
installed speech engine. If the engine does not expose a male Hindi voice, it
uses the device's default Hindi voice. Speech voice availability varies by
device and installed TTS service.

## Build requirements

Open the project directory in Android Studio with JDK 17 and Android SDK 35
installed. The project uses Android Gradle Plugin 8.7.3 and currently does not
include a Gradle wrapper.
