import { Router, type IRouter } from "express";
import OpenAI from "openai";
import rateLimit from "express-rate-limit";

const apiKey = process.env["OPENAI_API_KEY"];
const accessToken = process.env["JARVIS_ACCESS_TOKEN"];

if (!apiKey) {
  throw new Error("OPENAI_API_KEY must be configured in Secrets.");
}

if (!accessToken || accessToken.length < 24) {
  throw new Error(
    "JARVIS_ACCESS_TOKEN must be configured in Secrets and be at least 24 characters.",
  );
}

const client = new OpenAI({ apiKey });
const router: IRouter = Router();

router.get("/health", (_req, res) => {
  res.json({ status: "ok", name: "JARVIS" });
});

router.post(
  "/chat",
  rateLimit({
    windowMs: 60_000,
    limit: 10,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({ error: "Too many requests. Try again later." });
    },
  }),
  async (req, res) => {
    if (req.get("Authorization") !== `Bearer ${accessToken}`) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const message = req.body?.message;
    if (
      typeof message !== "string" ||
      !message.trim() ||
      message.length > 1500
    ) {
      res
        .status(400)
        .json({ error: "Message must be 1–1500 characters." });
      return;
    }

    try {
      const response = await client.responses.create({
        model: process.env["OPENAI_MODEL"] || "gpt-4.1-mini",
        instructions:
          "You are JARVIS, a Hindi-first personal assistant. Reply in Hindi by default; if the user speaks another language, reply in that language. Address the user as Sir, or सर in Hindi, in every reply. Do not claim you can control the phone or unlock it.",
        input: message.trim(),
        max_output_tokens: 350,
        store: false,
      });
      res.json({
        reply: response.output_text || "माफ़ कीजिए सर, अभी जवाब नहीं मिला।",
      });
    } catch (error) {
      const status =
        typeof error === "object" &&
        error !== null &&
        "status" in error &&
        typeof error.status === "number"
          ? error.status
          : undefined;
      req.log.error({ status }, "JARVIS AI request failed");
      res.status(502).json({
        error: "AI service unavailable. Check server logs, API access and billing.",
      });
    }
  },
);

export default router;
