const $ = (id) => document.getElementById(id);
const PIN_KEY = "jarvis_all_in_one_pin";
const DEFAULT_SERVER =
  "https://jarvis-server--Neeraj2004.replit.app/api/chat";
const SERVER_ENDPOINT_MIGRATION_KEY = "jarvis_server_endpoint_migration";
let attempts = 0;
let blockedUntil = 0;
let voices = [];
let waiting = false;
let nativeCallback = null;

const synth = window.speechSynthesis;

function showScreen(screen) {
  ["setup", "locked", "main"].forEach((id) => {
    $(id).classList.toggle("hide", id !== screen);
  });
}

function pinHash(value) {
  let hash = 2166136261;
  for (const character of value) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16);
}

function initialize() {
  let server = localStorage.getItem("jarvis_server");
  if (
    localStorage.getItem(SERVER_ENDPOINT_MIGRATION_KEY) !==
    "published-endpoint-v1"
  ) {
    server = DEFAULT_SERVER;
    localStorage.setItem(
      SERVER_ENDPOINT_MIGRATION_KEY,
      "published-endpoint-v1",
    );
  }
  server ||= DEFAULT_SERVER;
  $("server").value = server;
  localStorage.setItem("jarvis_server", server);
  showScreen(localStorage.getItem(PIN_KEY) ? "locked" : "setup");
  updateNetworkStatus();
  updateTokenStatus();
  loadVoices();
}

function updateNetworkStatus() {
  $("net").textContent = navigator.onLine ? "● ONLINE" : "○ OFFLINE";
}

function updateTokenStatus() {
  const hasToken =
    window.AndroidJarvis &&
    typeof window.AndroidJarvis.hasServerAccessToken === "function" &&
    window.AndroidJarvis.hasServerAccessToken();
  $("tokenStatus").textContent = hasToken
    ? "इस डिवाइस पर access token सुरक्षित है।"
    : "Online AI के लिए server access token सेव करें।";
}

function savePin() {
  const pin = $("newpin").value;
  if (!/^\d{4,8}$/.test(pin) || pin !== $("confirm").value) {
    $("setupmsg").textContent = "4–8 अंकों का एक जैसा PIN डालें।";
    return;
  }

  localStorage.setItem(PIN_KEY, pinHash(pin));
  $("newpin").value = "";
  $("confirm").value = "";
  showScreen("locked");
  $("lockmsg").textContent = "PIN सेट हो गया।";
}

function unlock() {
  if (Date.now() < blockedUntil) {
    $("lockmsg").textContent = "कुछ देर बाद प्रयास करें।";
    return;
  }

  if (pinHash($("pin").value) === localStorage.getItem(PIN_KEY)) {
    attempts = 0;
    $("pin").value = "";
    showScreen("main");
    speak("जी सर, जार्विस तैयार है।", true);
    return;
  }

  attempts += 1;
  $("lockmsg").textContent = "गलत PIN।";
  if (attempts >= 5) {
    attempts = 0;
    blockedUntil = Date.now() + 30_000;
    $("lockmsg").textContent = "बहुत प्रयास हुए। 30 सेकंड रुकें।";
  }
}

function loadVoices() {
  if (!synth) return;
  const current = $("voices").value;
  voices = synth.getVoices();
  $("voices").replaceChildren(new Option("डिफ़ॉल्ट आवाज़", ""));
  voices.forEach((voice, index) => {
    $("voices").add(new Option(`${voice.name} (${voice.lang})`, String(index)));
  });

  if (current !== "" && voices[Number(current)]) {
    $("voices").value = current;
    return;
  }

  const isHindiVoice = (voice) => voice.lang.toLowerCase().startsWith("hi");
  const isExplicitlyMale = (voice) => {
    const name = voice.name.toLowerCase();
    return name.includes("male") && !name.includes("female");
  };
  const hindiMaleVoiceIndex = voices.findIndex(
    (voice) => isHindiVoice(voice) && isExplicitlyMale(voice),
  );
  const hindiVoiceIndex = voices.findIndex(isHindiVoice);
  const preferredVoiceIndex =
    hindiMaleVoiceIndex >= 0 ? hindiMaleVoiceIndex : hindiVoiceIndex;
  if (preferredVoiceIndex >= 0) {
    $("voices").value = String(preferredVoiceIndex);
  }
}

function speak(text, force = false) {
  if (window.AndroidJarvis) {
    if (force || $("voice").checked) window.AndroidJarvis.speak(text);
    return;
  }

  if (!synth || (!force && !$("voice").checked)) return;
  synth.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  const selectedVoice = voices[Number($("voices").value)];
  if ($("voices").value !== "" && selectedVoice) {
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
  } else {
    utterance.lang = "hi-IN";
  }
  utterance.rate = 0.94;
  utterance.pitch = 0.9;
  utterance.onerror = (event) => {
    $("status").textContent = `आवाज़ त्रुटि: ${event.error}। दूसरी आवाज़ चुनें।`;
  };
  synth.speak(utterance);
}

function appendLog(speaker, text) {
  $("log").textContent += `\n${speaker}: ${text}\n`;
  $("log").scrollTop = $("log").scrollHeight;
}

function calculate(text) {
  const match = text.match(
    /(?:calculate|कैलकुलेट|हिसाब)\s*(-?\d+(?:\.\d+)?)\s*([+*/x×÷-])\s*(-?\d+(?:\.\d+)?)/i,
  );
  if (!match) return null;

  const left = Number(match[1]);
  const right = Number(match[3]);
  const operator = match[2];
  if ((operator === "/" || operator === "÷") && right === 0) {
    return "सर, शून्य से भाग नहीं कर सकते।";
  }

  const result =
    operator === "+"
      ? left + right
      : operator === "-"
        ? left - right
        : ["*", "x", "×"].includes(operator)
          ? left * right
          : left / right;
  return `सर, उत्तर है ${result}।`;
}

function offlineAnswer(rawText) {
  const text = rawText
    .toLowerCase()
    .replace(/hey\s*jarvis|हे\s*जार्विस|जार्विस|jarvis/g, "")
    .trim();
  if (!text) return "जी सर, बताइए क्या आदेश है?";

  const calculation = calculate(text);
  if (calculation) return calculation;
  if (/समय|time|टाइम/.test(text)) {
    return `सर, अभी ${new Date().toLocaleTimeString("hi-IN", {
      hour: "numeric",
      minute: "2-digit",
    })} बजे हैं।`;
  }
  if (/तारीख|date|दिनांक/.test(text)) {
    return `सर, आज ${new Date().toLocaleDateString("hi-IN", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    })} है।`;
  }
  if (/कहानी|story/.test(text)) {
    return "सर, एक गाँव में एक होशियार किसान रहता था। उसने मेहनत और समझदारी से सूखे खेत में भी हरियाली लौटा दी।";
  }
  if (/जोक|चुटकुला|joke/.test(text)) {
    return "सर, टीचर ने पूछा बिजली कहाँ से आती है? छात्र बोला, मामा के घर से, क्योंकि पापा कहते हैं फिर बिजली वालों ने काट दी!";
  }
  if (/नाम|कौन हो|who are you/.test(text)) {
    return "सर, मेरा नाम जार्विस है। मैं आपका पर्सनल असिस्टेंट डेमो हूँ।";
  }
  if (/unlock|अनलॉक/.test(text)) {
    return "सर, फोन अनलॉक करने के लिए Android का आधिकारिक PIN या बायोमेट्रिक इस्तेमाल करें।";
  }
  if (/नमस्ते|hello|hi|हेलो/.test(text)) {
    return "नमस्ते सर! मैं आपकी क्या सहायता कर सकता हूँ?";
  }
  if (/मदद|help|क्या कर सकते/.test(text)) {
    return "सर, मैं समय, तारीख, कहानी, चुटकुला और सामान्य हिसाब बता सकता हूँ।";
  }
  if (/मौसम|weather/.test(text)) {
    return "सर, लाइव मौसम के लिए ऑनलाइन मौसम सेवा जोड़नी होगी।";
  }
  return "क्षमा कीजिए सर, यह कमांड अभी उपलब्ध नहीं है। मदद लिखकर कमांड देखें।";
}

function setBusy(isBusy) {
  waiting = isBusy;
  $("send").disabled = isBusy;
  $("mic").disabled = isBusy;
}

function handleMessage(rawText) {
  const text = rawText.trim();
  if (!text) return;
  appendLog("YOU", text);

  const localReply = offlineAnswer(text);
  if (
    localReply.startsWith("क्षमा कीजिए") &&
    $("onlineAI").checked &&
    navigator.onLine &&
    window.AndroidJarvis
  ) {
    const server = $("server").value.trim();
    if (!server) {
      $("status").textContent = "Online AI के लिए HTTPS server URL सेट करें।";
      appendLog("JARVIS", $("status").textContent);
      return;
    }
    if (!server.startsWith("https://")) {
      $("status").textContent = "सुरक्षा के लिए HTTPS server URL इस्तेमाल करें।";
      appendLog("JARVIS", $("status").textContent);
      return;
    }
    if (waiting) return;

    localStorage.setItem("jarvis_server", server);
    setBusy(true);
    $("status").textContent = "सर, ऑनलाइन AI से पूछ रहा हूँ…";
    window.AndroidJarvis.askAI(text, server);
    return;
  }

  $("status").textContent = localReply;
  appendLog("JARVIS", localReply);
  speak(localReply);
}

function listen(callback) {
  if (window.AndroidJarvis) {
    nativeCallback = callback;
    window.AndroidJarvis.listen();
    return;
  }

  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    callback(null, "इस ब्राउज़र में आवाज़ पहचान उपलब्ध नहीं है। टेक्स्ट इस्तेमाल करें।");
    return;
  }

  try {
    const recognition = new SpeechRecognition();
    recognition.lang = "hi-IN";
    recognition.interimResults = false;
    recognition.onresult = (event) =>
      callback(event.results[0][0].transcript, null);
    recognition.onerror = (event) =>
      callback(null, `माइक्रोफोन त्रुटि: ${event.error}।`);
    recognition.start();
  } catch {
    callback(null, "माइक्रोफोन शुरू नहीं हुआ।");
  }
}

window.jarvisSpeechResult = (speech, error) => {
  if (!nativeCallback) return;
  const callback = nativeCallback;
  nativeCallback = null;
  callback(speech, error);
};

window.jarvisAIResult = (reply) => {
  setBusy(false);
  $("status").textContent = reply;
  appendLog("JARVIS", reply);
  speak(reply);
};

$("savePin").onclick = savePin;
$("unlock").onclick = unlock;
$("pin").onkeydown = (event) => {
  if (event.key === "Enter") unlock();
};
$("relock").onclick = () => {
  synth?.cancel();
  showScreen("locked");
};
$("test").onclick = () =>
  speak("नमस्ते सर, मैं जार्विस हूँ। क्या आपको मेरी आवाज़ सुनाई दे रही है?", true);
$("send").onclick = () => {
  handleMessage($("cmd").value);
  $("cmd").value = "";
};
$("cmd").onkeydown = (event) => {
  if (event.key === "Enter") $("send").click();
};
$("server").onchange = () =>
  localStorage.setItem("jarvis_server", $("server").value.trim());

$("saveServerToken").onclick = () => {
  const token = $("serverToken").value;
  if (!window.AndroidJarvis) {
    $("tokenStatus").textContent = "Android secure storage उपलब्ध नहीं है।";
    return;
  }
  if (token.trim().length < 24) {
    $("tokenStatus").textContent =
      "सही server access token डालें (कम से कम 24 अक्षर)।";
    return;
  }

  const saved = window.AndroidJarvis.saveServerAccessToken(token);
  $("serverToken").value = "";
  $("tokenStatus").textContent = saved
    ? "Token इस डिवाइस पर सुरक्षित सेव हुआ।"
    : "Token सुरक्षित सेव नहीं हो पाया। फिर कोशिश करें।";
};

$("forgetServerToken").onclick = () => {
  if (!window.AndroidJarvis) return;
  const forget = window.confirm("इस डिवाइस से server token हटाएँ?");
  if (!forget) return;
  const removed = window.AndroidJarvis.clearServerAccessToken();
  $("tokenStatus").textContent = removed
    ? "इस डिवाइस से token हटा दिया गया।"
    : "Token नहीं हट पाया।";
};

$("mic").onclick = () => {
  $("status").textContent = "सुन रहा हूँ सर…";
  listen((speech, error) => {
    if (error) {
      $("status").textContent = error;
      return;
    }
    handleMessage(speech || "");
  });
};

$("voiceUnlock").onclick = () =>
  listen((speech, error) => {
    if (error) {
      $("lockmsg").textContent = error;
      return;
    }
    if (/jarvis|जार्विस|unlock|अनलॉक/i.test(speech || "")) {
      $("lockmsg").textContent = "जी सर, कृपया PIN डालें।";
      speak("जी सर, कृपया अपना पिन दर्ज करें।", true);
      $("pin").focus();
    } else {
      $("lockmsg").textContent = `कमांड पहचाना नहीं गया: ${speech || ""}`;
    }
  });

$("phone").onclick = () => {
  const reply =
    "सर, यह ऐप Android का सिस्टम लॉक नहीं खोल सकता। फोन का आधिकारिक PIN, फिंगरप्रिंट या फेस अनलॉक इस्तेमाल करें।";
  $("status").textContent = reply;
  appendLog("JARVIS", reply);
  speak(reply);
};

addEventListener("online", updateNetworkStatus);
addEventListener("offline", updateNetworkStatus);
if (synth) {
  loadVoices();
  synth.onvoiceschanged = loadVoices;
  setTimeout(loadVoices, 800);
}

initialize();
