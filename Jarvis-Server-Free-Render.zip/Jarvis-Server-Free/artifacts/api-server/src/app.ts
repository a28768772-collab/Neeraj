import express, {
  type ErrorRequestHandler,
  type Express,
} from "express";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.disable("x-powered-by");
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(express.json({ limit: "12kb" }));
app.use(express.urlencoded({ extended: true }));

app.get("/health", (_req, res) => {
  res.json({ status: "ok", name: "JARVIS" });
});

app.use("/api", router);

const requestBodyErrorHandler: ErrorRequestHandler = (
  error: unknown,
  _req,
  res,
  next,
) => {
  if (typeof error === "object" && error !== null && "status" in error) {
    if (error.status === 413) {
      res.status(413).json({ error: "Request body is too large." });
      return;
    }

    if (
      error.status === 400 &&
      "type" in error &&
      error.type === "entity.parse.failed"
    ) {
      res.status(400).json({ error: "Invalid JSON request body." });
      return;
    }
  }

  next(error);
};

app.use(requestBodyErrorHandler);

export default app;
